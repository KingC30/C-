#include <iostream>
const int WORD_INPUT = 4; 
using namespace std;

void populateArray(char array[WORD_INPUT]);
void printArray(char array[WORD_INPUT]);

int main() {
  char myWord[]; 
  populateArray(myWord);
  printArray(myWord);
  return 0;
}
void populateArray(char array[]) {
  char tempWord[WORD_INPUT];
  cout << "Enter a " << WORD_INPUT << " letter word: " << endl;
  cin >> tempWord;
  for(int i = 0; i <= WORD_INPUT; i++) { 
    array[i] = tempWord[i];
  }
}
void printArray(char array[]) {
  int i = (WORD_INPUT); 
  while(i >= 0) {
    cout << array[i];
    i++; 
  }
  cout << endl;
}
