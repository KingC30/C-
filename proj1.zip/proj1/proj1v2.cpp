/* Gia Bao Vo
cmsc 202
section 11
9/18/2021*/
#include <iostream>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <cmath>
#include<cstdlib>
#include <string>
using namespace std;
const string Get_File_Name = "proj1_p1.txt";
const int WIN_GAME= 0;
const char SPACE = ' ';
const char UNDER_SCORE= '_';

int main (){
    loadFile();
    return 0;
}
void startGame(string wordList[], int size)
{

}

void loadFile()
{
    ifstream filex(Get_File_Name); // Declares and opens a file.
    int size = 0;
    string LW = {};
    cout << "Welcome to UMBC words search" << endl;
    if (filex.is_open())
    {
        while (filex >> LW)
        {
            size++;
        }
        filex.close();
        filex.open(Get_File_Name);
        string wordList[size] = {};
        for (int i = 0; i < size; i++)
        {
            filex >> LW;
            wordList[i] = LW;
        }
        filex.close();
        cout << "225 letters imported " << endl;
        cout << size << " words beenimported!." << endl;
        startGame(wordList, size);
    }
    else
    {
        cout << "Unable to open file"
            << endl; //If the input file does not exist, notifies user
        cout << "Game is terminated, make sure the file is correct" << endl;
    }
}