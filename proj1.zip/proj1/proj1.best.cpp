#include <iostream>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <cmath>
#include <cstdlib>
#include <string>

using namespace std;

const string Get_File_Name = "proj1_p1.txt";
const int WIN_GAME= 0;
const char SPACE = ' ';
const char UNDER_SCORE= '_';


void loadFile();
void startGame(string wordList[], int size);
void showGrid(string board[][15], string wordList[], int size);
string checkWord(string board[][15], string wordList[], int size, int x, int y, int x1, int y1);


int main() {
    loadFile();
    return 0;
}

void showGrid(string board[][15], string wordList[], int size) {
  // print grid
    for( int i = -1; i < 15; i++) {
        for ( int j = -1; j< 15; j++) {
                
            // complicated if statements to print out the indexes on the side
            if (i == -1) {
                if (j==-1 ) {
                    cout << "   ";
                } else {
                    cout << setw(3) << j;
                }
            }
            if (j == -1 && i>-1) {
                cout << setw(3) << i;
            }
            if (j >-1 && i> -1) {
                cout << setw(3) << board[i][j];
            }
        }
        cout << endl;
    }

    // print out remaining words
    cout << "*********REMAINING WORDS*********" << endl;
    for (int i = 0; i < size; i++) {
        if(wordList[i] != "-") {
            cout << wordList[i] << endl;
        }
    }
}
string checkWord(string board[][15], string wordList[], int size, int x, int y, int x1, int y1) {

    /**
    - left to right
    - right to left
    - top to bottom
    - bottom to top
    - diagonally
        - top left bottom right
        - top right bottom left
        - bottom left top right
        - bottom right top left


    in reality all we need to do is

    - left to right
    - top to bottom
    - top left bottom right
    - bottom left top right

    and then reverse them
    **/

    // assuming that input is good,
    // that is, for diagonals, the difference in x and y are equal

    int xDiff = x1 - x;
    int yDiff = y1 - y;

    int xp = x;
    int yp = y;
    string r= board[xp][yp];

    while(xp != x1 || yp != y1) {
        
        if(xDiff < 0) {
            xp -=1;
        }
        if (xDiff > 0 ) {
            xp+=1;
        }
        if(yDiff <0 ) {
            yp-=1;
        }
        if(yDiff > 0) {
            yp+=1;
        }
        r += board[xp][yp];
    }
        // reverse the string to check the opposite direction
    string reversed = "";
    size = r.length()-1;
    for (int i = size; size>=0; size--) {
        reversed+= r.at(size);
    }

    // checking if we found a word
    for (int i = 0; i < 10; i++) {
        if (wordList[i] == r ) {
            wordList[i] = "-";
            return r;
        }
        if(wordList[i] == reversed) {
            wordList[i] = "-";
            return reversed;
        
        }
    }

    return "-";
}

void gameLoop(string board[][15], string wordList[], int size)
{
    int x = 0;
    int y = 0;

    int x1 = 0;
    int y1 = 0;

    int s = size;
    string removed;

    do{ 
        showGrid(board, wordList, size); 
        cout << "What is the starting X Y (separated by a space)?" << endl;
        cin >> x;
        cin >> y;
        cout << "What is the ending X Y (separated by a space)?" << endl;
        cin >> x1;
        cin >> y1;

        // check if point in grid
        if (x < 0 || x >14 || y < 0 || y > 14 || x1 < 0 || x1 > 14 || y1 <0 || y1 > 14) {
            cout << "That point is not in the grid";
        }

        // check if selected points lead to a word and if they do, remove them
        removed = checkWord(board, wordList, s, x, y, x1, y1);
        if(removed == "-") {
            cout << "You didn't fine a word on the list" << endl;
        } else {
            cout << "You found the word " << removed << "!" << endl;
            s--;
        }
    }while(s > 0);
}  

void loadFile()
{
    string fileName;
    string board[15][15];
    int size = 10;
    string wordList[10];

    cout << "Welcome to UMBC Word Search" << endl;
    cout << "What is the name of file you would like to load?" << endl;

    // cin  the file name
    cin >> fileName;
    // read file
    fstream file;
    string word;
    file.open(fileName.c_str());

    int x = 0;
    int y = 0;

    int wC= 0;
    
    // extracting words/characters from the file
    while (file >> word)
    {
        if(x < 15 && y < 15) {
            board[x][y] = word;
            y++;
        if(y==15) {
            y=0;
            x++;
        }
        } else {
            wordList[wC] = word;
            wC++;
        }
    }

    cout << "225 letters imported." << endl;
    cout << "10 words imported." << endl;

    // game loop
    gameLoop(board,wordList,size);

    cout << "Thanks for playing !";
}