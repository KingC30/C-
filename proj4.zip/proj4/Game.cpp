#include "Game.h"

// Name: Game() - Default Constructor
// Description: Creates a new Game. Welcomes player to UMBC Mario Kart. Initializes laps and racers to 1
// Preconditions: None
// Postconditions: m_numLaps and m_numRacers initialized to 1
Game::Game(){
    m_numLaps = 1;
    m_numRacers = 1;
    m_playerName="";

    cout << "************Welcome to UMBC Mario Kart*************" << endl;
}
// Name: ~Game
// Description: Destructor
// Preconditions: None
// Postconditions: Deallocates anything dynamically allocated in Game
Game::~Game(){
    //deletes each racer
    for (unsigned int i = 0; i < m_Racers.size() ; ++i) {
        delete m_Racers[i];
        m_Racers[i] = nullptr;
    }
    m_numLaps = 0;
    m_numRacers=0;
    m_playerName="";
}
// Name: LoadTrack
// Description: Asks user which track to use (1-3)
//              Calls LoadTrack for use in myTrack
//              If three laps then the same track is loaded three times
// Precondition: Files must exist. m_numLaps must be populated
// Postcondition: myTrack is populated with track Pieces
void Game::LoadTrack() {
    int track_num;
    //loops to check for invalid inputs
    do {
        cin.clear();
        cout << "What track would you like to use?\n1. Mario's\n2. Mario Circuit \n3. Ultra Race" << endl;
        cin >> track_num;
        cin.ignore(256, '\n');
    } while (track_num > 3 || track_num < 1);
    for (int i = 0; i < m_numLaps; ++i) {
        myTrack.LoadTrack(TRACK[track_num - 1][1]);
    }
    cout << "You will be racing " << m_numLaps << " lap(s)" << endl;
    cout << "The total length of the race is " << myTrack.GetTotalLength() << " meters"<< endl;

}
// Name: RaceSetup
// Description: Asks the user for their name and stores it in local variable
//              Allows user to choose which racer to use (Mario, Wario, or Toad) using provided name
//              Allows the user to choose how many other racers to use (no limit) - Randomly assigned (can be duplicates)
//              Allows the user to choose how many laps to race (no limit)
// Preconditions: None
// Postconditions: m_Racers populated with racers, m_numLaps populated
void Game::RaceSetup(){
    string name;
    int racer, num_competitors, num_laps;
    cout << "What is your name?" << endl;
    getline(cin, name); //double output for some reason...
    cout << "Select a Racer\n1. Toad\n2. Wario\n3. Mario" << endl;
    cin >> racer;
    cin.ignore(256,'\n');
    while(racer > 3 || racer < 1){
        cin.clear();
        cin.ignore(256, '\n');
        cout << "Select a Racer\n1. Toad\n2. Wario\n3. Mario" << endl;
        cin >> racer;
    }
    if (racer == 1){
        m_Racers.push_back(new Toad(name,TOAD_STATS[0], TOAD_STATS[1], TOAD_STATS[2]));
    }
    if (racer == 2){
        m_Racers.push_back(new Mario(name,MARIO_STATS[0], MARIO_STATS[1], MARIO_STATS[2]));
    }
    if (racer == 3){
        m_Racers.push_back(new Wario(name,WARIO_STATS[0],WARIO_STATS[1],WARIO_STATS[2]));
    }

    cout << "How many competitors would you like?" << endl;
    cin >> num_competitors;
    cin.ignore();
    cout << "How many laps would you like to complete for the race?" << endl;
    cin >> num_laps;
    m_playerName = name;
    m_numRacers = num_competitors + 1;
    m_numLaps = num_laps;

    for (int i = 0; i < num_competitors; i++){
        int type = (rand()%3)+1;
        if (type == 1){
            m_Racers.push_back(new Toad("CPU", TOAD_STATS[0], TOAD_STATS[1], TOAD_STATS[2]));
        }
        else if (type == 2){
            m_Racers.push_back(new Mario("CPU", MARIO_STATS[0], MARIO_STATS[1], MARIO_STATS[2]));
        }
        else if (type == 3){
            m_Racers.push_back(new Wario("CPU", WARIO_STATS[0], WARIO_STATS[1], WARIO_STATS[2]));
        }
    }
}
// Name: StartRace()
// Description: As long as the race isn't over or the user hasn't quit repeat these:
//              Displays current position in track for user
//              Shows round number
//              Displays current piece description on track
//              Displays the next piece description on track (like what is ahead)
//              Makes computer racers randomly choose a speed for this round (100%, 75%, 50%, 25%)
//              Tick (passing max speed)
//              Reorder vector based on who has moved the most down the track (m_curLocation)
//              Display the order
// Preconditions: LoadTrack and RaceSetup must have been completed
// Postconditions: Continues until race is over. If completed, displays result (who won)
void Game::StartRace(){
    myTrack.DisplayPiece(0);

    // find user racer
    int index = FindPlayer();
    int round = 0;
    int gas;
    double gas2;
    do {
        if (round == 0) {
            cout << "\n"
                    "*********ON YOUR MARKS*********\n"
                    "\n"
                    "*********GET SET*********\n"
                    "\n"
                    "*********GO! GO! GO!*********\n" << endl;
        } else {
            cout << "************************" << endl;
            cout << "Round : " << round << endl;
            cout << "************************" << endl;
        }

        double maxspeed = m_Racers[index]->GetTopSpeed();
        cout << "You currently see:" << endl;
        myTrack.DisplayPiece(m_Racers[index]->GetCurLocation());
        if (round == 0) {
            Order();
            gas = Action();
            gas2 = gas;
            gas2 = gas2/100;
            m_Racers[index]->CalcSpeed(gas2);
            m_Racers[index]->Tick(maxspeed);
            CpuRandom();
        } else {
            Order();
            cout << "Ahead is:" << endl;
            myTrack.DisplayPiece(m_Racers[index]->GetCurLocation() + 1);
            gas = Action();
            gas2 = gas;
            gas2 = gas2/100;
            m_Racers[index]->CalcSpeed(gas2);
            m_Racers[index]->Tick(maxspeed);
            CpuRandom();
        }
        cout << "************************" << endl;
        Display();
        cout << "************************" << endl;
        round++;
    }while (!CheckFinish());
}
// Name: CheckFinish
// Description: Checks to see if any racer has exceeded total length of the track
// Precondition: m_Racers has been populated and myTrack has been populated
// Postcondition: Returns true if race is over; else false
bool Game::CheckFinish(){
    for (int i = 0; i < m_numRacers; i++){
        if (m_Racers[i]->GetCurLocation() > myTrack.GetTotalLength()){
            cout<< "Winner is " << m_Racers[i]->GetName() << " !" << endl;
            return true;
        }
    }
    return false;

}
// Name: CpuRandom
// Description: Iterates over all computer m_Racers and uses CalcSpeed to randomly assign either (100%, 75%, 50%, 25%)
// Precondition: m_Racers has been populated
// Postcondition: Using CalcSpeed, updates racer's speeds
void Game::CpuRandom(){
    double gas[] = {1.0, 0.75, 0.50, 0.25};
    for (int i = 0; i < m_numRacers; i++){
        if (m_Racers[i]->GetName() == "CPU"){
            int index = (rand()%4);
            m_Racers[i]->CalcSpeed(gas[index]);
            m_Racers[i]->Tick(m_Racers[i]->GetTopSpeed());
        }

    }

}
// Name: Tick
// Description: Iterates over all computer m_Racers and calls Tick and passes the maxSpeed of the current piece of track that racer is on
// Precondition: m_Racers has been populated and myTrack has been populated
// Postcondition: Checks to see if the racer crashes by exceeding the max limit of that track piece
void Game::Tick(double MaxSpeed)
{
    for (unsigned int i = 1; i < m_Racers.size(); i++)
    {
        m_Racers.at(i)->Tick(MaxSpeed);
    }
}
// Name: Order
// Description: Uses a simple bubble sort (nested for loops) to reorder who has traveled the farthest
// Precondition: m_Racers has been populated
// Postcondition: m_Racers is sorted from highest distance traveled to lowest distance traveled
void Game::Order()
{
    Entity *temp = nullptr;
    for (unsigned int i = 0; i < m_Racers.size(); i++)
    {
        for (unsigned int j = i + 1; j < m_Racers.size(); j++)
        {
            //reorder if one is further
            if (m_Racers.at(j)->GetCurLocation() > m_Racers.at(i)->GetCurLocation())
            {
                temp = m_Racers.at(i);
                m_Racers.at(i) = m_Racers.at(j);
                m_Racers.at(j) = temp;
            }
        }
    }
}
// Name: Display
// Description: Displays each racer in m_Racers by using overloaded << operator
// Precondition: m_Racers has been populated
// Postcondition: Usage is *m_Racers.at(i) << cout << endl;
void Game::Display(){
    for (unsigned i = 0; i < m_Racers.size(); ++i) {
        *m_Racers.at(i) << cout;
    }

}
// Name: FindPlayer
// Description: Iterates over all racers in m_Racers to return the index of where the player's racer exists (after sort)
// Precondition: m_Racers has been populated and sort has been called
// Postcondition: Returns the index of where the player's racer exists
int Game::FindPlayer()
{
    int playerIndex = 0;
    for (unsigned int i = 0; i < m_Racers.size(); i++)
    {
        if (m_Racers.at(i)->GetName() == m_playerName)
        {
            playerIndex = i;
            return playerIndex;
        }
    }
    return playerIndex;
}
// Name: Action()
// Description: Menu for game
//              Required to implement cases 1-4 and 6.
//              Choice 5 (Attack) is optional and is part of the extra credit
//              Asks the user if they want to change their speed
// Preconditions: Everything in start has been completed
// Postconditions: Game continues until someone finishes race
int Game::Action(){
    int userinput;
    //loops to check for invalid inputs
    do
    {
        do
        {
            cin.clear();
            cout << "What would you like to do?" << endl;
            cout << "1. Max Speed\n2. Pretty Fast\n3. Fast\n4. Slow\n5. Use Obstacle\n6. Quit" << endl;
            cin >> userinput;
            cin.ignore(256, '\n');
        } while (userinput < 1 || userinput > 6);
        if (userinput == 1) {
            return 100;
        }
        else if (userinput == 2)
        {
            return 75;
        }
        else if (userinput == 3) {
            return 50;
        }
        else if (userinput == 4) {
            return 25;
        }
        else if (userinput == 5) {
            return 0;
        }
    } while (userinput != 6);
    return -1;
}

