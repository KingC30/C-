#include "Track.h"

Track::Track(){
    m_totalLength = 0;
}

Track::~Track() {
    for (unsigned int i = 0; i < m_track.size(); ++i) {
        delete m_track[i];
        m_track[i] = nullptr;
    }
}

void Track::LoadTrack(string fileName){
    string pieceLength, pieceDes, pieceNum, pieceMaxSpeed, trackName, trackDes;
    m_fileName = fileName;

    int Total_Length = 0;

    char vertical = '|';

    int totalTracksLoaded = 0;

    ifstream myFile(m_fileName);

    if (myFile.is_open())
    {
        getline(myFile, trackName);
        getline(myFile, trackDes);
        while (getline(myFile, pieceLength, vertical))
        {
            getline(myFile, pieceDes, vertical);
            getline(myFile, pieceNum, vertical);
            getline(myFile, pieceMaxSpeed);

            Total_Length += stoi(pieceLength);

            Piece *newPiece = new Piece(stoi(pieceLength), pieceDes,
                                        stoi(pieceNum), stoi(pieceMaxSpeed));

            m_track.push_back(newPiece);
        }
        m_totalLength = Total_Length;
        totalTracksLoaded++;
        myFile.close();
    }
    else
    {
        cout << "Unable to open file." << endl;
    }
}

int Track::GetPiece(int distance){
    int total_distance = 0;
    for(unsigned int i=0;i<m_track.size();++i){
        total_distance += m_track[i]->m_length;
        if(distance < total_distance) {
            return i;
        }
    }
}

void Track::DisplayPiece(int index) {
    if(index >= 0 && index <= m_track.size()){
        cout << m_track[index]->m_desc << endl;
    }
}

double Track::GetMaxSpeed(int index) {
    if(index > 0 && index <= m_track.size()){
        return m_track[index]->m_maxSpeed;
    }
}

int Track::GetTotalLength() {
    return m_totalLength;
}

std::string Track::GetDesc(){
    return m_desc;
}