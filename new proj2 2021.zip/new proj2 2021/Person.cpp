
#include <iostream>
#include <string>
#include "Organization.h"
#include "Person.h"
#include "FriendFinder.h"

using namespace std;

// Name: Person
// Desc - Default Constructor for a Person
// Preconditions - Creates a Person with no data associated with it
// Postconditions - a Person is created
Person::Person() {
    m_fName = "";
    m_lName = "";
    m_ID = 0;
    m_age = 0;
    m_friendCount = 0;
    for (int i = 0; i < MAX_FRIENDS; ++i) {
        m_friends[i] = nullptr;
    }
}
// Name: Person
// Desc - Overloaded Constructor for a Person
// Preconditions - Creates a Person with passed data
// Postconditions - a Person is created
Person::Person(string fname, string lname , int age, int id) {
    m_fName =fname;
    m_lName =lname;
    m_ID =id;
    m_age =age;
    m_friendCount = 0;
    for (int i = 0; i < MAX_FRIENDS; ++i) {
        m_friends[i] = nullptr;
    }
}
// Name: AddFriend
// Desc - A person pointer is stored from the roster of people in an organization
// Preconditions - A person pointer is passed
// Postconditions - A person pointer is added to this person's m_friend's array
//                  if not at maximum and not already in the array
void Person::AddFriend(Person* person){
    if (m_friendCount < MAX_FRIENDS && !CheckID(person->m_ID)){
        m_friends[m_friendCount] = person;
        cout << "You are now friends with " << person->m_fName << "!" << endl;
        m_friendCount++;
        }
    else if (CheckID(person->m_ID)){
        cout << "You are already friends with them!" << endl;
    }
    else{
        cout << "You can Only have max of 10 friends" << endl;
    }

}
// Name: RemoveFriend
// Desc - Removes a person pointer from this person's m_friend array
// Preconditions - Person pointer exists in m_friend
// Postconditions - Person is removed from m_friend and all pointers are moved towards front
void Person::RemoveFriend() {
    int userinput; //instantiates the string userinput
    for (int i = 0; i < m_friendCount; ++i) {
        cout << i + 1 << ". ";
        m_friends[i]->DisplayDetails();
    }
    cout << "Who would you like to remove? " << endl; //gets the name of the ship
    cin >> userinput;
    if(m_friendCount == 0){
        cout << "no friends to remove" << endl;
    }
    else{
        int iterator = 0;
        int count = 0;
        while(iterator != (userinput-1) && count != 1 && iterator < m_friendCount){
            if(iterator ==(userinput - 1)){
                m_friendCount = m_friendCount - 1;
                count++;
            }
            iterator++;
        }
        for (int j= iterator; j < m_friendCount; j++)
            m_friends[j] = m_friends[j+1];
        cout << "removed from friends list" << endl;
        m_friendCount--;
    }
    }
// Name: CheckID
// Desc - Checks to see if a specific person ID exists in m_friends - Note: IDs will always be unique in proj2
// Preconditions - m_friends is populated
// Postconditions - Returns true if id exists in m_friends else false
bool Person::CheckID(int id){
    for (int i = 0; i < m_friendCount; ++i) {
        if (id == m_friends[i]->m_ID){
            return true;
        }
    }
    return false;

}
// Name: DisplayFriends
// Desc - Displays information about each friend in the m_friend array
// Preconditions - People are in the m_friend array
// Postconditions - Displays information about person object in array
void Person::DisplayFriends() {
    if (m_friendCount == 0){
        cout << "You dont have any friends yet" << endl;
    }
    else{
        for (int i = 0; i < m_friendCount; ++i) {
            cout << i+1 << ". ";
            m_friends[i]->DisplayDetails();
        }
    }
}
// Name: DisplayDetails
// Desc - Displays information about this person
// Preconditions - Person data is populated
// Postconditions - Displays information about person object
void Person::DisplayDetails(){
    cout << m_fName << " " << m_lName << " (" << m_age << " yrs) " << m_ID << endl;
}
// Name: SetDetails
// Desc - Used as a setter for first name, last name, age, and id
// Preconditions - Person already created
// Postconditions - Member variables populated
void Person::SetDetails(string first_name, string last_name , int age , int id){
    m_fName = first_name;
    m_lName = last_name;
    m_age = age;
    m_ID = id;
}
