
#include <iostream>
#include <string>
#include "Organization.h"
#include "Person.h"
#include "FriendFinder.h"

using namespace std;

// Name: Organization
// Desc - Default constructor for Organization
// Preconditions - None
// Postconditions - Organization is created (empty) with 0 people in the roster
Organization::Organization(){
    m_name ="";
    m_numRoster = 0;
    for (int i = 0; i < MAX_PEOPLE; ++i) {
        m_roster[i] = Person("","",0,0);
    }

}
// Name: SetName
// Desc - Sets m_name by asking user for name
// Preconditions - m_name exists
// Postconditions - Asks user for the organization name and populates m_name
void Organization::SetName(){
    string userinput; //instantiates the string userinput
    cout << "What is the name of your organization? " << endl;
    getline(cin, userinput);
    m_name = userinput;
}
// Name: LoadRoster
// Desc - Sets m_fileName by asking user. Then populates all of the people loaded from file
// Preconditions - m_fileName exists. m_roster empty
// Postconditions - Asks user for m_fileName. Loads data from file and populates m_roster
void Organization::LoadRoster(){
    SetName();
    m_fileName = FILE_NAME;
    ifstream myfile(m_fileName);
    if (myfile.is_open()) {
        for (int i = 0; i < MAX_PEOPLE; i++)
        {
            //creates fname ,lname ,age, ID
            string fname;
            string lname;
            string age;
            string ID;
            getline(myfile, fname, ',');
            getline(myfile, lname, ',');
            getline(myfile, age, ',');
            getline(myfile, ID, '\n');
            int ID2 = stoi(ID);
            int age2 = stoi(age);
            m_roster[i] = Person(fname, lname, age2, ID2);
            //loads the roster
        }
        m_numRoster = MAX_PEOPLE;
        cout << MAX_PEOPLE << " people loaded into the roster" << endl;
    }
    else
    {
        cout << "file did not open" << endl;
    }
    myfile.close(); //closes file
}
// Name: DisplayRoster
// Desc - Displays a numbered list of everyone in the roster (starts at 1)
// Preconditions - m_roster is populated
// Postconditions - Displays a numbered list of people
void Organization::DisplayRoster() {
    for (int i = 0; i < m_numRoster; ++i) {
        cout << i + 1 << ". " ;
        m_roster[i].DisplayDetails();
    }
}
// Name: GetPerson
// Desc - Displays a list of people in m_roster and user enters number of desired person.
//        Returns pointer of that person in m_roster
// Preconditions - m_roster is populated
// Postconditions - Returns pointer for the person chosen from list
Person* Organization::GetPerson(){
    for (int i = 0; i < m_numRoster; ++i) {
        cout << i + 1 << ". " ;
        m_roster[i].DisplayDetails();
    }
    int userinput;
    cin >> userinput;
    if (userinput < 0 || userinput > MAX_PEOPLE){
        do {
            cout << "Please enter correct number in range." << endl;
            cin >> userinput;
        }while(userinput < 0 || userinput > MAX_PEOPLE );
    }
    Person *pointerOfPerson = &m_roster[userinput - 1];
    return pointerOfPerson;
}
