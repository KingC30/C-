
#include <iostream>
#include <string>
#include "Organization.h"
#include "Person.h"
#include "FriendFinder.h"

using namespace std;

// Name: FriendFinder
// Desc - Default constructor for application for finding friends
// Preconditions - Creates a Person and an organization
// Postconditions - Welcomes user and calls Start()
FriendFinder::FriendFinder(){
    cout << "***************************** \n Welcome to UMBC Friend Finder \n*****************************" << endl;
    m_organization.LoadRoster();
    m_me = Person("","",0,0);
    Start();
}
// Name: GetDetails
// Desc - Asks user for their first name, last name, age, and ID to populate m_me
// Preconditions - None
// Postconditions - Populates information related to m_me
void FriendFinder::GetDetails(){
    string fname;
    string lname;
    int age;
    int id;
    cout << "What is your first name? " << endl;
    cin >> fname;
    cout << "What is your last name? " << endl;
    cin >> lname;
    cout << "What is your age? " << endl;
    cin >> age;
    cout << "What is your ID? " << endl;
    cin >> id;
    m_me.SetDetails(fname, lname, age, id);
}
// Name: DisplayMenu
// Desc - Displays main menu for application
// Preconditions - None
// Postconditions - Called from Start updates integer passed
void FriendFinder::DisplayMenu(int &choice){
    if (choice == 1){
        m_organization.DisplayRoster();
    }
    if (choice == 2){
        m_me.DisplayFriends();
    }
    if (choice == 3){
        cout << "Who would you like to friend?" << endl;
        Person *friendtoadd = m_organization.GetPerson();
        m_me.AddFriend(friendtoadd);
    }
    if (choice == 4){
        m_me.RemoveFriend();
    }

}
// Name: Start
// Desc - Main function running FriendFinder
//        Calls GetDetails
//        Populates data for organization
//        Continually calls DisplayMenu until someone enters 4 (exit)
// Preconditions - m_me and m_organization are created but not populated
// Postconditions - Runs until user enters 4. Thanks user for usage. Ends application
void FriendFinder::Start(){
    GetDetails();
    int userinput;
    do {
        cout << "What would you like to do?" << endl;
        cout << "1. Display Entire Organization \n2. Display Friend List \n3. Search for a Friend \n4. Remove Friend \n5. Exit " << endl;
        cin >> userinput;
        DisplayMenu(userinput);
        cin.clear();
    } while (userinput != 5);
    cout << "Thank you for using UMBC Friend Finder!" << endl;
}
