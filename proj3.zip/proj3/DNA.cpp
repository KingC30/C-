#include "DNA.h"
#include <string>
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

DNA::DNA()
{
	m_head = NULL;
	m_tail = NULL;
	m_size = 0;
}

DNA::~DNA()
{
	Clear();
}

void DNA::Clear()
{
  Node *temp = m_head;
  //iterates through the DNA and sets the temp equal to whatever Node m_head is pointing at and
  //sets temp to the next Node and then deletes m_head and then sets head to the temp
  while (m_head != NULL)
    {
      temp = m_head->m_next;
      delete m_head;
      m_head = temp;
    }
  m_head = NULL;
  m_tail = NULL;
  m_size = 0;
}

void DNA::InsertEnd(char data)
{
  Node * head = m_head;
  Node * temp = new Node;
  temp->m_data = data;
  temp->m_next = NULL;
  if(m_head == NULL)
    {
      m_head = temp;
    }
  else
    {
      //goes through the loop and inserts the data into the last  Node
      while(head->m_next != NULL)
	{
	  head = head->m_next;
	}
      head->m_next = temp;
    }
}

string DNA::GetName()
{
    return m_name;
}


int DNA::GetSize()
{
  Node *temp = m_head;
  int count = 0;
  while(temp != NULL)
    {
      count++;
      temp = temp->m_next;
    }
  //had to create a count and have that equal to m_size because if I did m_size++
  //the code would increase m_size too much and would cause a seg fault.
  m_size = count;
  return m_size;
}

void DNA :: ReverseSequence(){

    Node* current = m_head;
    Node *prev = NULL;
    Node * next= NULL;
 
        while (current != NULL) {
            // Store next
            next = current->m_next;
 
            // Reverse current node's pointer
            current->m_next = prev;
 
            // Move pointers one position ahead.
            prev = current;
            current = next;
        }
        m_head = prev;
}


bool DNA::CompareSequence(DNA &evidence){
Node* first = evidence.m_head;
Node* second = m_head;
Node* ptr1 = first, *ptr2 = second;

    // If both linked lists are empty, return true
    if (first == NULL && second == NULL)
        return true;
  
    // Else If one is empty and other is not return
    // false
    if ( first == NULL ||
        (first != NULL && second == NULL))
        return false;
  
    // Traverse the second list by picking nodes
    // one by one
    while (second != NULL)
    {
        // Initialize ptr2 with current node of second
        ptr2 = second;
  
        // Start matching first list with second list
        while (ptr1 != NULL)
        {
            // If second list becomes empty and first
            // not then return false
            if (ptr2 == NULL)
                return false;
  
            // If data part is same, go to next
            // of both lists
            else if (ptr1->m_data == ptr2->m_data)
            {
                ptr1 = ptr1->m_next;
                ptr2 = ptr2->m_next;
            }
  
            // If not equal then  break the loop
            else break;
        }
  
        // Return true if first list gets traversed
        // completely that means it is matched.
        if (ptr1 == NULL)
            return true;
  
        // Initialize ptr1 with first again
        ptr1 = first;
  
        // And go to next node of second list
        second = second->m_next;
    }
  
    return false;
}

char DNA::GetData(int nodeNum)
{
  Node * temp = m_head;
  int count = 0;
  //iterates through m_dna objects and returns the individual data from each strand
  while(count < nodeNum)
    {
      temp = temp->m_next;
      count++;
    }
  return temp->m_data;
}

int DNA::Display()
{
  int count = 0;
  if (m_head == NULL)
    {
      cout << "The Linked List is empty" << endl;
    }
  else
    {
      //creates a new temp node that loops through the DNA and outputs the data
      Node *temp = m_head;
      while(temp != NULL)
	{
	  cout << temp->m_data << "->";
	  temp = temp->m_next;
	  count++;
	}
       cout << "END" << endl;
    }
  return count;
}

ostream &operator<< (ostream &output, DNA &myDNA)
{
  //outputs the display function 
  output << myDNA.Display();
  return output;
}
  