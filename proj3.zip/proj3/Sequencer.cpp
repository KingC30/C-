#include "Sequencer.h"

#include "DNA.h"

#include <fstream>
#include <string>
#include <iostream>
#include <cstdlib>
#include <vector>
using namespace std;


Sequencer::Sequencer(string fileName)
{
  m_fileName = fileName;
  ReadFile();
  MainMenu();
}

Sequencer::~Sequencer()
{
  for(unsigned int i=0;i<m_evidence.size();i++)
    {
      DNA *remove = m_evidence.at(i);
      delete remove;
    }
}


void Sequencer::DisplayStrands()
{
  //outputs the deferenced vector object at each index
  for(int i=0;i<(int)m_evidence.size();i++)
    {
      cout << *m_evidence.at(i) << endl;
    }
}


void Sequencer::ReadFile()
{

  DNA *newDNA = new DNA;
  ifstream infile;
  int strandNum = 1;
  int count = 0;
  infile.open(m_fileName.c_str());
  char data;
  while(infile >> data)
    {
      //has the new DNA  call the InsertEnd function and input the char data from the textfile
      //into the newDNA .
      newDNA->InsertEnd(data);
      if (infile.peek() == '\n')
	{
	  cout << "Strand " << strandNum << " with " << newDNA->GetSize() << " nucleotides"<< endl;
	  //had the count = this because Display returned an integer
	  count = newDNA->Display();
	  //pushes the newDNA DNA into the m_dna vector
	  m_evidence.push_back(newDNA);
	  strandNum++;
	  //create a new DNA to keep creating a filling for each strand
	  newDNA = new DNA;
	}
    }
  infile.close();
  cout << "File loaded, number of strands is: "  << strandNum-1 << endl;
  delete newDNA;
}


void Sequencer::MainMenu()
{
  int menu;
  do
    {
      cout << "What would you like to do?" << endl;
      cout << "1. Display Strands" << endl;
      cout << "2. check suspect" << endl;
      cout << "3. reverse sequence" << endl;
      cout << "4. Exit" << endl;
      cin >> menu;
      switch(menu)
	{
	case 1:
	  {
	    DisplayStrands();
	  }
	  break;
	case 2:
	  {
	    CheckSuspects();
	  }
	  break;
	case 3:
	  {
	    ReverseSequence();
	  }
	  break;
	case 4:
	  {
	    cout << "Thank you" << endl;
	  }
	  break;
	}
    }while(menu != 4);
}
// Name:  CheckSuspects
  // Desc: Iterates through each DNA strand in m_suspects to see if there is a match from
  //       m_evidence. Displays each suspect strand where the evidence matches
  // Preconditions: Populated m_suspects and m_evidence
  // Postconditions: Displays each suspect that has a match
void Sequencer::CheckSuspects() {
  cout << "Checking suspects and evidence" << endl;
  int counter = 0;
  //loops through both evidence and the suspects
  for (int i = 0; i < m_suspects.size(); i++) {
    for (int j = 0; j < m_evidence.size(); j++) {
      if (m_suspects[j]->CompareSequence(*m_suspects[i])) {
        cout << "Suspect " << j + 1 << " DOES match with evidence " << i + 1 << endl;
        counter = counter + 1;
        //adds to counter
        if (counter == m_suspects.size()) {
          cout << "Suspect " << j + 1 << " matches with ALL evidence" << endl;
        //checks to see whether it matches with all evidence
        }
      }
      else {
        cout << "Suspect " << j + 1 << " does NOT match with evidence " << i + 1 << endl;
        //if it doesn't match with evidence
      }
    }
  }
} 

  // Name: ReverseSequence
  // Desc: User chooses a sequence from m_suspects or m_evidence and the sequence is reversed
  // Preconditions: Populated m_suspects and m_evidence
  // Postconditions: Reverses a specific sequence replacing in place
void Sequencer:: ReverseSequence(){

    cout<< "reversing sequences of dna"<<endl;
    

    int choices;
    cout << "what sequences do you want to reverse"<<endl;
    cin >> choices;
    m_evidence.at(choices)->ReverseSequence();
    
    cout << m_evidence.at(choices) << endl;
}

