/************************************
File: Sequencers.cpp
Project: CMSC 202 Project 3
Author: Gia Bao Vo
Date: 4/1/2021
This code implements the files from the Sequencer.h file. The .cpp file displays the strands,
reads in the file, outputs a menu, calculates the consensus, and mutates the strands
*************************************/
#include "Sequencer.h"

#include "DNA.h"

#include <fstream>
#include <string>
#include <iostream>
#include <cstdlib>
#include <vector>
using namespace std;


Sequencer::Sequencer(string fileName)
{
  m_fileName = fileName;
  ReadFile();
  MainMenu();
}

Sequencer::~Sequencer()
{
  for(unsigned int i=0; i<m_evidence.size(); i++) {
      DNA *remove = m_evidence.at(i);
      delete remove;
    }
}


void Sequencer::DisplayStrands() {
  for(int i=0;i<(int)m_evidence.size();i++) {
      cout << *m_evidence.at(i) << endl;
    }
}


void Sequencer::ReadFile() {
  DNA *newDNA = new DNA;
  ifstream infile;
  int strandNum = 1;
  int count = 0;
  infile.open(m_fileName.c_str());
  char data;
do {
  newDNA->InsertEnd(data);
  if (infile.peek() == '\n') {
    cout << "Strand " << strandNum << " contains " << newDNA->GetSize() << " nucleotides"<< endl;
    count = newDNA -> Display();
    m_evidence.push_back(newDNA);
    strandNum += 1;
    newDNA = new DNA;}
}  while(infile >> data);
  infile.close();
  cout << strandNum-1 << " strands" << endl;
  delete newDNA;
}




void Sequencer::MainMenu() {
  int menu;
while (menu != 4) {
    cout << "Select one: " << endl;
    cout << "1: Display strands" << endl;
    cout << "2: Check suspect" << endl;
    cout << "3: Reverse sequence" << endl;
    cout << "4: Exit" << endl;
    cin >> menu;
    if (menu == 1) {
      DisplayStrands();
    } else if (menu == 2) {
      CheckSuspects();
    } else if (menu == 3) {
      ReverseSequence();
    } else {
      cout << "Goodbye" << endl;
    }
}
}


void Sequencer::CheckSuspects() {
  int counter = 0;
  for (int i = 0; i < m_suspects.size(); i++) {
    for (int j = 0; j < m_evidence.size(); j++) {
      if (m_suspects[j]->CompareSequence(*m_suspects[i])) {
        cout << "Suspect " << j + 1 << " matches evidence " << i + 1 << endl;
        counter = counter + 1;
        if (counter == m_suspects.size()) {
          cout << "Suspect " << j + 1 << " matches all evidence" << endl;
        }
      }
      else {
        cout << "Suspect " << j + 1 << " doesn't match evidence " << i + 1 << endl;
      }
    }
  }
} 
void Sequencer:: ReverseSequence(){

    cout<< "reversing sequences of dna"<<endl;
    

    int choices;
    cout << "what sequences do you want to reverse"<<endl;
    cin >> choices;
    m_evidence.at(choices)->ReverseSequence();
    
    cout << m_evidence.at(choices) << endl;
}
