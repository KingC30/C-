//
//  Runner.cpp
//  Project 5 - Templates
//
//  Created by Nathenael Dereb
//

#ifndef RUNNER_CPP
#define RUNNER_CPP

#include <cstdlib>
#include "Vector.cpp"
using namespace std;

template <class T>
class Runner
{
public:
    // Name: Default Constructor
    // Precondition: None
    // Postcondition: Initiates state/environment
    Runner(Vector<T> *, Vector<T> *);

    // Name: mainMenu
    // Desc: Main Menu
    // Precondition: Existing Vectors
    // Postcondition: Handles various menu commands
    int mainMenu();

private:
    Vector<T> m_vector1;
    Vector<T> m_vector2;
};

// **** Add class definition below ****

template <class T>
Runner<T>::Runner(Vector<T> *a, Vector<T> *b)
{
    m_vector1 = *a;
    m_vector2 = *b;
}

template <class T>
int Runner<T>::mainMenu()
{
    int menuChoice;

    while (menuChoice != 9)
    {

        cout << "Choose an option" << endl;

        cout << "1. Display Vectors" << endl
             << "2. Vector comparison (<)" << endl
             << "3. Vector comparison(==)" << endl
             << "4. Vector addition" << endl
             << "5. Vector multiplication" << endl
             << "6. Computer median" << endl
             << "7. Computer mean" << endl
             << "8. Compute Standard Deviation" << endl
             << "9. Exit" << endl
             << endl;
        cin >> menuChoice;

        switch (menuChoice)
        {
        case 1:
            cout << "Vector 1: ";
            m_vector1.Display();
            cout << endl;
            cout << "Vector 2: ";
            m_vector2.Display();
            cout << endl;
            break;
        case 2:
            cout << "Vector1 < Vector2: ";
            (m_vector1 < m_vector2)->Display();
            cout << endl;
            break;
        case 3:
            cout << "Vector1 == Vector2: ";
            (m_vector1 == m_vector2)->Display();
            cout << endl;
            break;
        case 4:
            cout << "Vector1 + Vector2: ";
            (m_vector1 + m_vector2)->Display();
            cout << endl;
            break;
        case 5:
            cout << "Vector1 * Vector2: ";
            (m_vector1 * m_vector2)->Display();
            cout << endl;
            break;
        case 6:
            cout << "Vector1 median: " << m_vector1.Median() << endl;
            cout << "Vector2 median: " << m_vector2.Median() << endl;
            break;
        case 7:
            cout << "Vector1 mean: " << m_vector1.Mean() << endl;
            cout << "Vector2 mean: " << m_vector2.Mean() << endl;
            break;
        case 8:
            cout << "Vector1 Standard Deviation: " << m_vector1.StDev() << endl;
            cout << "Vector2 Standard Deviation: " << m_vector2.StDev() << endl;
            break;
        case 9:
            return 0;
        default:
            continue;
        }
    }
    return 0;
}

#endif /* Runner_h */
