//
//  Vector.cpp
//  Project 5 - Templates
//
//  Created by Nathenael Dereb on 2/8/21.
//

#ifndef VECTOR_CPP
#define VECTOR_CPP

#include <string>
#include <fstream>
#include <iostream>
#include <cmath>

using namespace std;

template <class T>
struct Node
{
public:
  Node(T value)
  {
    m_value = value;
    next = nullptr;
  }

  Node(T value, Node *_next)
  {
    m_value = value;
    next = _next;
  }

  T getValue()
  {
    return m_value;
  }

  Node<T> *getNextNode()
  {
    return next;
  }

  void setNextNode(Node<T> *newNode)
  {
    next = newNode;
  }

private:
  T m_value;
  Node<T> *next;
};

template <class T>
class Vector
{
public:
  // Name: Default Constructor
  // Precondition: None (Must be templated)
  // Postcondition: Creates a vector using a linked list
  Vector();

  // Name: Destructor
  // Desc: Frees memory
  // Precondition: Existing Vector
  // Postcondition: Destructs existing Vector
  ~Vector();

  // Name: Copy Constructor
  // Desc: Copies an existing vector
  // Precondition: Existing Vector
  // Postcondition: Two identical vectors (in separate memory spaces)
  // Hint: Utilize overloaded [] operator
  Vector(Vector<T> *const &source);

  // Name: Overloaded Assignment operator
  // Desc: Assingns a vector
  // Precondition: Existing Vector
  // Postcondition: Assigns a vector
  // Hint: Utilize overloaded [] operator
  Vector<T> *operator=(Vector<T> *source);

  // Name: Overloaded [] operator
  // Desc: to retrive use [indx]
  // Precondition: Existing Vector
  // Postcondition: Returns the value of the element at the given index
  T operator[](int indx);

  // Name: Insert
  // Desc: insert a node to the end of the vector
  // Precondition: Existing Vector
  // Postcondition: A vector with the newly added value
  void Insert(T);

  // Name: SortedInsert
  // Desc: Inserts a node into the vector at it's correct position (sorted ascendingly)
  // Precondition: Existing Vector
  // Postcondition: sorted vector (low to high)
  void SortedInsert(T);

  // Name: Remove
  // Desc: removes a node from the vector
  // Precondition: Existing Vector
  // Postcondition: A vector that holds the results of the vectors added
  void Remove(int indx);

  // Name: Overloaded + operator | Vector Addition
  // Desc: Adds two vectors and returns the result
  // Precondition: Existing Vector, vectors can be of different size
  // Postcondition: A vector that holds the results of the vectors added
  Vector<T> *operator+(Vector<T> &source);

  // Name: Overloaded * operator | Vector Multiplication
  // Desc: Multiplys two vectors and returns the result
  // Precondition: Existing Vector, vectors can be of different size
  // Postcondition: returns a vector that holds the results of the vectors multiplied
  Vector<T> *operator*(Vector<T> &other);

  // Name: Overloaded < operator | Vector Comparision
  // Desc: Compares two vectors [using the < operator] and returns the result
  // Precondition: Existing Vector -> vectors need to be of the same size
  // Postcondition: returns a vector that holds the boolean char (T or F) value of each node comparison
  Vector<char> *operator<(Vector<T> &other);

  // Name: Overloaded == operator | Vector Comparision
  // Desc: Compares two vectors [using the == operator] and returns the result
  // Precondition: Existing Vector, vectors need to be of the same size
  // Postcondition: returns a vector that holds the boolean char (T or F) value of each node comparison
  Vector<char> *operator==(Vector<T> &other);

  // Name: Size
  // Desc: number of nodes in Vector
  // Precondition: Existing Vector
  // Postcondition: returns the size of the vector
  int Size();

  // Name: Display
  // Desc: displays the contents of the vector
  // Precondition: Existing Vector
  // Postcondition: prints to console the contents of Vector
  void Display();

  // Name: median
  // Desc: Computes the median of the vector
  // Precondition: Existing Vector
  // Postcondition: returns the median value
  float Median();

  // Name: Mean
  // Desc: Computes the mean of the vector
  // Precondition: Existing Vector
  // Postcondition: returns the mean value
  float Mean();

  // Name: StDev
  // Desc: Computes the standard derivation of the vector
  // Precondition: Existing Vector
  // Postcondition: returns the standard derivation
  float StDev();

private:
  Node<T> *m_head;
};

// **** Add class definition below ****
//TODO:
template <class T>
Vector<T>::Vector()
{
  m_head = 0;
};

template <class T>
Vector<T>::~Vector()
{
  Node<T> *current = m_head;
  while (current != 0)
  {
    Node<T> *next = current->getNextNode();
    delete current;
    current = next;
  }
};

template <class T>
Vector<T>::Vector(Vector<T> *const &source)
{
  int size = source->Size();
  for (int i = 0; i < size; i++)
  {
    Insert((*source)[i]);
  }
};

template <class T>
Vector<T> *Vector<T>::operator=(Vector<T> *source)
{
  return source;
};

template <class T>
T Vector<T>::operator[](int indx)
{
  int counter = 0;
  Node<T> *current = m_head;
  while (current != 0)
  {
    if (counter == indx)
    {
      return current->getValue();
    }

    current = current->getNextNode();
    counter++;
  }
  // this should never run
  return 0;
};

template <class T>
void Vector<T>::Insert(T t)
{

  // if undefined
  if (m_head == 0)
  {
    m_head = new Node<T>(t);
    return;
  }

  // get last value in vector
  Node<T> *current = m_head;
  while (current != 0 && current->getNextNode() != 0)
  {
    current = current->getNextNode();
  }

  // appent to last value in vector
  Node<T> *temp = new Node<T>(t);
  current->setNextNode(temp);
};

template <class T>
void Vector<T>::SortedInsert(T t)
{
  Node<T> *current = m_head;
  // if undefined
  if (m_head == 0)
  {
    Insert(t);
    return;
  }

  if (t <= current->getValue())
  {
    Node<T> *temp = new Node<T>(t, current);
    m_head = temp;
    return;
  }

  while (current->getNextNode() != 0)
  {
    // less than or equal to the next one
    // AND
    // greater than or equal the the current one
    if (t >= current->getValue() && t <= current->getNextNode()->getValue())
    {
      Node<T> *temp = new Node<T>(t, current->getNextNode());
      current->setNextNode(temp);
      return;
    }
    current = current->getNextNode();
  }

  // insert to the end
  Insert(t);
};

template <class T>
void Vector<T>::Remove(int indx)
{
  int counter = 0;

  Node<T> *current = m_head;

  // if index == 1
  if (indx == 0)
  {
    m_head = m_head->getNextNode();
    delete current;
    return;
  }

  // if index > 1
  while (current != 0)
  {
    if (counter + 1 == indx)
    {
      Node<T> *temp = current->getNextNode();
      current->setNextNode(current->getNextNode()->getNextNode());
      delete temp;
      return;
    }
    current = current->getNextNode();
    counter++;
  }
};

template <class T>
Vector<T> *Vector<T>::operator+(Vector<T> &source)
{
  Vector<T> *v = new Vector<T>();

  int size_a = Size();
  int size_b = source.Size();
  int size = size_a > size_b ? size_a : size_b;

  for (int i = 0; i < size; i++)
  {
    v->Insert((*this)[i] + source[i]);
  }
  return v;
};

template <class T>
Vector<T> *Vector<T>::operator*(Vector<T> &other)
{
  // since different length vectors are multiplied, I am treating no value as 0
  // this is because something multiplied with nothing is nothing !

  Vector<T> *v = new Vector<T>();

  int size_a = Size();
  int size_b = other.Size();
  int size = size_a > size_b ? size_a : size_b;

  for (int i = 0; i < size; i++)
  {
    v->Insert((*this)[i] * other[i]);
  }
  return v;
};

template <class T>
Vector<char> *Vector<T>::operator<(Vector<T> &other)
{
  Vector<char> *v = new Vector<char>();

  int size = Size();

  for (int i = 0; i < size; i++)
  {
    if ((*this)[i] < other[i])
    {
      v->Insert('T');
    }
    else
    {
      v->Insert('F');
    }
  }

  return v;
};

template <class T>
Vector<char> *Vector<T>::operator==(Vector<T> &other)
{
  Vector<char> *v = new Vector<char>();

  int size = Size();

  for (int i = 0; i < size; i++)
  {
    if ((*this)[i] == other[i])
    {
      v->Insert('T');
    }
    else
    {
      v->Insert('F');
    }
  }

  return v;
};

template <class T>
int Vector<T>::Size()
{
  int counter = 0;
  Node<T> *current = m_head;
  while (current != 0)
  {
    current = current->getNextNode();
    counter++;
  }
  return counter;
};

template <class T>
void Vector<T>::Display()
{
  int size = Size();
  for (int i = 0; i < size; i++)
  {
    cout << (*this)[i];
    if (i + 1 != size)
    {
      cout << ", ";
    }
  }
};

template <class T>
float Vector<T>::Median()
{
  int size = Size();
  // cout << size;
  // if length = 1
  if (size == 1)
  {
    return (*this)[0];
  }
  // if even elements, mean of the two middle ones
  if (size % 2 == 0)
  {
    return ((*this)[size / 2] + (*this)[size / 2 - 1]) / 2;
  }
  // if odd elements, return the middle element
  return (*this)[(size - 1) / 2];
};

template <class T>
float Vector<T>::Mean()
{
  Node<T> *current = m_head;
  float sum = 0;
  while (current != 0)
  {
    sum += current->getValue();
    current = current->getNextNode();
  }
  return sum / Size();
};

template <class T>
float Vector<T>::StDev()
{
  float mean = Mean();
  float sum = 0;
  Node<T> *current = m_head;

  while (current != 0)
  {
    float diff = current->getValue() - mean;
    sum += diff * diff;

    current = current->getNextNode();
  }
  return sqrt(sum / Size());
};

#endif /* VECTOR_CPP */
